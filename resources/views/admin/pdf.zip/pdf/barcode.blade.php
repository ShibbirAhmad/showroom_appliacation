<html>

<head>

    <title>
        Print
    </title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

</head>

<style>
   
  
    .col-lg-2{
      width: 135px;
     margin-bottom: 5px;
     display: inline-block;
     text-align: center;
     
    }
    .page button{
      position: fixed;
    width: 100px;
    left: 92%;
    background: green;
    color: #fff;
    padding: 10px 13px;
    border-radius: 5px;
    top: 50%;
    border: none;
    cursor: pointer;
    }
    
   
    @media print {
   button {
    display: none;
   }
  }
</style>
<script type="text/javascript">
  function print_document(){
 
    window.print();
  }
</script>

<body>
    <div class="page">
        <button onclick="print_document()">Print</button>
      @for ($i = 1; $i <= $howmany; $i++)
      <div class="col-lg-2">
          {!! $product_barcode->barcode !!}
          <span style="letter-spacing: 5px;"> {{ $product_barcode->barcode_number }}</span>
      </div>
      @endfor
    </div>
    
     
      
</body>

</html>
